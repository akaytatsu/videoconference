var crypto = window.crypto || window.msCrypto;

function randomValueHex (len) {
    var array = new Uint32Array(1);

    return window.crypto.getRandomValues(array);
}

function getRoomId(){
    return randomValueHex(4)+"-"+randomValueHex(4)+"-"+randomValueHex(4);
}

$(document).ready(function(){
    
});